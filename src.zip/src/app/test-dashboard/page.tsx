import EnhancedEmployeeDashboard from '@/components/enhanced-employee-dashboard'

export default function TestDashboardPage() {
  return <EnhancedEmployeeDashboard />
}